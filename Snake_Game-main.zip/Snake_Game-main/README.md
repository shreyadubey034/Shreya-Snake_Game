# Snake_Game
Live link :- https://ayushtyagijod.github.io/Snake_Game/

# This is a classic Snake game. The player controls a snake that moves around the screen, eating food and growing in length. The game features a score system and keeps track of the player's highest score. It also includes sound effects and graphics to enhance the gaming experience.
